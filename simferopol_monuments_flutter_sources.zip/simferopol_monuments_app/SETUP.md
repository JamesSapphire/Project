## Setup (recommended)
This folder contains the **lib/** and **assets/** of the app.

To make it a full Flutter app with Android/iOS folders:

1) Create a new Flutter project:
   flutter create simferopol_monuments

2) Copy/replace into that project:
   - replace the new project's `lib/` with this folder's `lib/`
   - replace/add `assets/` folder
   - replace the new project's `pubspec.yaml` with this folder's `pubspec.yaml`
   - run: flutter pub get

3) IMPORTANT for ONLINE MAP (Android):
   Ensure the app has Internet permission.
   In `android/app/src/main/AndroidManifest.xml` add inside `<manifest>`:
     <uses-permission android:name="android.permission.INTERNET" />

4) Run:
   flutter run

This approach avoids shipping big platform folders and works on Windows/macOS/Linux.
