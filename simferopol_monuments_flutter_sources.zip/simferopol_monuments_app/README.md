# Simferopol Monuments

## Features
- Cross-platform Flutter app (Android/iOS)
- RU/EN language switch (saved between launches)
- **Online map (OpenStreetMap tiles)** for minimal app size + perfect geometry
- Markers for monuments; tap -> photo + description panel
- Soft white / lavender UI theme with gradient buttons

## How to run
1. Install Flutter
2. `flutter pub get`
3. `flutter run`

## Android note (important)
Online map requires Internet permission in `android/app/src/main/AndroidManifest.xml`:
`<uses-permission android:name="android.permission.INTERNET" />`

## Replace photos
Images are placeholders. Replace files in `assets/images/monuments/` keeping filenames.

## Edit monuments list
`lib/data/monuments.dart`
