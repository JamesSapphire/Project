# Simferopol Monuments (Offline Map)

## What you get
- Cross-platform Flutter app (Android/iOS)
- RU/EN language switch (saved between launches)
- Offline map using local tiles: `assets/tiles/{z}/{x}/{y}.png`
- Markers for monuments; tap -> photo + description panel
- Soft white / lavender UI theme

## How to run
1. Install Flutter
2. `flutter pub get`
3. `flutter run`

## Offline tiles (important)
The project ships with a **placeholder** tile at `assets/tiles/0/0/0.png`.
To see a real map offline, add tiles to:
`assets/tiles/{z}/{x}/{y}.png`

Common ways:
- Export a tile set from OpenStreetMap using Mobile Atlas Creator (MOBAC) (then unpack into the folder structure)
- Or generate tiles from an MBTiles file (advanced)

After adding tiles, run:
- `flutter clean`
- `flutter pub get`
- `flutter run`

## Replace photos
Images are placeholders. Replace files in `assets/images/monuments/` keeping filenames.

## Edit monuments list
`lib/data/monuments.dart`
