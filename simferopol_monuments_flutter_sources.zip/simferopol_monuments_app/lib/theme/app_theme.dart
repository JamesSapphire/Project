import 'package:flutter/material.dart';

class AppTheme {
  // Soft palette
  static const lavender = Color(0xFFB39DDB);
  static const purpleWarm = Color(0xFF7E57C2);
  static const textGrey = Color(0xFF6B6B6B);

  static const bg = Color(0xFFF6F4FA);
  static const glassWhite = Color.fromARGB(235, 255, 255, 255);

  // Gentle gradients
  static const primaryGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [lavender, purpleWarm],
  );

  static const softBackgroundGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Color(0xFFF6F4FA), Color(0xFFFFFFFF)],
  );

  static ThemeData build() {
    final base = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: purpleWarm),
    );

    return base.copyWith(
      scaffoldBackgroundColor: bg,
      textTheme: base.textTheme.apply(
        bodyColor: textGrey,
        displayColor: textGrey,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        foregroundColor: textGrey,
        centerTitle: true,
      ),
      cardTheme: const CardThemeData(
        color: glassWhite,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(22))),
      ),
    );
  }
}
