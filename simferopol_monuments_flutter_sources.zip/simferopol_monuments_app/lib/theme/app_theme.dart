import 'package:flutter/material.dart';

class AppTheme {
  static const lavender = Color(0xFFB39DDB);
  static const purpleWarm = Color(0xFF7E57C2);
  static const softGrey = Color(0xFF6B6B6B);
  static const glassWhite = Color.fromARGB(235, 255, 255, 255);

  static ThemeData build() {
    final base = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: purpleWarm),
    );

    return base.copyWith(
      scaffoldBackgroundColor: const Color(0xFFF6F4FA),
      textTheme: base.textTheme.apply(
        bodyColor: softGrey,
        displayColor: softGrey,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        foregroundColor: softGrey,
        centerTitle: true,
      ),
      cardTheme: CardTheme(
        color: glassWhite,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: purpleWarm,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: purpleWarm,
          side: const BorderSide(color: lavender, width: 1.4),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        ),
      ),
    );
  }
}
