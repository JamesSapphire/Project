import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class GradientButton extends StatefulWidget {
  final VoidCallback? onPressed;
  final Widget child;
  final EdgeInsets padding;
  final bool compact;
  final bool outlined;
  final IconData? icon;

  const GradientButton({
    super.key,
    required this.onPressed,
    required this.child,
    this.padding = const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
    this.compact = false,
    this.outlined = false,
    this.icon,
  });

  @override
  State<GradientButton> createState() => _GradientButtonState();
}

class _GradientButtonState extends State<GradientButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(widget.compact ? 14 : 18);

    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapCancel: () => setState(() => _down = false),
      onTapUp: (_) => setState(() => _down = false),
      onTap: widget.onPressed,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 120),
        scale: _down ? 0.98 : 1.0,
        child: AnimatedOpacity(
          duration: const Duration(milliseconds: 120),
          opacity: widget.onPressed == null ? 0.55 : 1.0,
          child: Container(
            padding: widget.padding,
            decoration: BoxDecoration(
              gradient: widget.outlined ? null : AppTheme.primaryGradient,
              color: widget.outlined ? AppTheme.glassWhite : null,
              borderRadius: radius,
              border: Border.all(
                color: AppTheme.lavender.withOpacity(widget.outlined ? 0.7 : 0.0),
                width: widget.outlined ? 1.4 : 0.0,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.purpleWarm.withOpacity(widget.outlined ? 0.08 : 0.22),
                  blurRadius: widget.outlined ? 12 : 18,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (widget.icon != null) ...[
                  Icon(widget.icon, size: 20, color: widget.outlined ? AppTheme.purpleWarm : Colors.white),
                  const SizedBox(width: 10),
                ],
                DefaultTextStyle(
                  style: TextStyle(
                    fontSize: 15.5,
                    fontWeight: FontWeight.w600,
                    color: widget.outlined ? AppTheme.purpleWarm : Colors.white,
                    letterSpacing: 0.2,
                  ),
                  child: widget.child,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
