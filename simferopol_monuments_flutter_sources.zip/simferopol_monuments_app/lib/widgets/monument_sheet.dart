import 'package:flutter/material.dart';
import '../models/monument.dart';
import '../theme/app_theme.dart';
import 'glass_card.dart';

class MonumentSheet extends StatelessWidget {
  final Monument monument;
  final String lang;

  const MonumentSheet({super.key, required this.monument, required this.lang});

  @override
  Widget build(BuildContext context) {
    final title = monument.titleFor(lang);
    final desc = monument.descriptionFor(lang);

    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
        child: GlassCard(
          withGlow: true,
          padding: const EdgeInsets.all(14),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                height: 4,
                width: 42,
                decoration: BoxDecoration(
                  color: AppTheme.lavender.withOpacity(0.8),
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
              const SizedBox(height: 12),

              ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: Image.asset(
                  monument.imageAsset,
                  height: 190,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),

              const SizedBox(height: 12),

              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(
                      gradient: AppTheme.primaryGradient,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(Icons.place, color: Colors.white, size: 18),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      title,
                      style: const TextStyle(
                        fontSize: 17.5,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.textGrey,
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 10),

              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  desc,
                  style: TextStyle(
                    fontSize: 14,
                    height: 1.38,
                    color: AppTheme.textGrey.withOpacity(0.95),
                  ),
                ),
              ),

              const SizedBox(height: 10),

              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Источник: ${monument.source}',
                  style: TextStyle(fontSize: 12, color: AppTheme.textGrey.withOpacity(0.68)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
