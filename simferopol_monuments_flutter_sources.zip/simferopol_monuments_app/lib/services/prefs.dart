import 'package:shared_preferences/shared_preferences.dart';

class Prefs {
  static const _langKey = 'lang';

  static Future<String> getLang() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_langKey) ?? 'ru';
  }

  static Future<void> setLang(String lang) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_langKey, lang);
  }
}
