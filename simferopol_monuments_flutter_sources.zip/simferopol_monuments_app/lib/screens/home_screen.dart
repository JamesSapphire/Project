import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../data/monuments.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';
import '../widgets/gradient_button.dart';
import 'language_screen.dart';
import 'map_screen.dart';

class HomeScreen extends StatefulWidget {
  final String lang;
  final ValueChanged<String> onLangChanged;

  const HomeScreen({super.key, required this.lang, required this.onLangChanged});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    final isRu = widget.lang == 'ru';

    return Scaffold(
      body: Stack(
        children: [
          // Soft gradient background
          Container(decoration: const BoxDecoration(gradient: AppTheme.softBackgroundGradient)),

          // Decorative blobs
          Positioned(
            top: -140,
            left: -80,
            child: _Blob(size: 280, opacity: 0.22),
          ),
          Positioned(
            bottom: -160,
            right: -100,
            child: _Blob(size: 320, opacity: 0.18, flip: true),
          ),

          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 12, 18, 18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _TopBar(
                    title: isRu ? 'Памятники Симферополя' : 'Simferopol Monuments',
                    subtitle: isRu ? 'интерактивная карта' : 'interactive map',
                  ),
                  const SizedBox(height: 14),

                  GlassCard(
                    withGlow: true,
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          width: 46,
                          height: 46,
                          decoration: BoxDecoration(
                            gradient: AppTheme.primaryGradient,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(
                                color: AppTheme.purpleWarm.withOpacity(0.22),
                                blurRadius: 18,
                                offset: const Offset(0, 10),
                              )
                            ],
                          ),
                          child: const Icon(Icons.map_outlined, color: Colors.white),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                isRu ? 'Открой карту города' : 'Open the city map',
                                style: const TextStyle(
                                  fontSize: 16.5,
                                  fontWeight: FontWeight.w700,
                                  color: AppTheme.textGrey,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                isRu
                                    ? 'Нажимай на метки — увидишь фото и описание памятника.'
                                    : 'Tap markers to view a photo and a short description.',
                                style: TextStyle(
                                  color: AppTheme.textGrey.withOpacity(0.88),
                                  height: 1.3,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 14),

                  // Quick stats + preview list
                  Row(
                    children: [
                      Expanded(
                        child: GlassCard(
                          padding: const EdgeInsets.all(14),
                          child: _MiniStat(
                            title: isRu ? 'Точек на карте' : 'Markers',
                            value: '${monuments.length}',
                            icon: Icons.place_outlined,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: GlassCard(
                          padding: const EdgeInsets.all(14),
                          child: _MiniStat(
                            title: isRu ? 'Язык' : 'Language',
                            value: isRu ? 'RU' : 'EN',
                            icon: Icons.language,
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  Text(
                    isRu ? 'Быстрые действия' : 'Quick actions',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textGrey.withOpacity(0.85),
                      letterSpacing: 0.3,
                    ),
                  ),
                  const SizedBox(height: 10),

                  Row(
                    children: [
                      Expanded(
                        child: GradientButton(
                          icon: Icons.map_outlined,
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (_) => MapScreen(lang: widget.lang)));
                          },
                          child: Text(isRu ? 'К карте' : 'Open map'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: GradientButton(
                          outlined: true,
                          icon: Icons.language,
                          onPressed: () async {
                            final newLang = await Navigator.push<String>(
                              context,
                              MaterialPageRoute(builder: (_) => LanguageScreen(current: widget.lang)),
                            );
                            if (newLang != null) widget.onLangChanged(newLang);
                          },
                          child: Text(isRu ? 'Язык' : 'Language'),
                        ),
                      ),
                    ],
                  ),

                  const Spacer(),

                  Center(
                    child: GradientButton(
                      compact: true,
                      outlined: true,
                      icon: Icons.exit_to_app,
                      onPressed: () => SystemNavigator.pop(),
                      child: Text(isRu ? 'Выход' : 'Exit'),
                    ),
                  ),

                  const SizedBox(height: 8),
                  Center(
                    child: Text(
                      isRu
                          ? 'Карта загружается онлайн (OpenStreetMap). Фото и описания — локально.'
                          : 'Map loads online (OpenStreetMap). Photos & text are stored locally.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppTheme.textGrey.withOpacity(0.6), fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  final String title;
  final String subtitle;

  const _TopBar({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: AppTheme.glassWhite,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.lavender.withOpacity(0.45)),
          ),
          child: const Icon(Icons.location_city, color: AppTheme.purpleWarm),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppTheme.textGrey)),
              Text(subtitle, style: TextStyle(color: AppTheme.textGrey.withOpacity(0.7))),
            ],
          ),
        ),
      ],
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _MiniStat({required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            gradient: AppTheme.primaryGradient,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Icon(icon, color: Colors.white, size: 20),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: TextStyle(color: AppTheme.textGrey.withOpacity(0.72), fontSize: 12.5)),
              const SizedBox(height: 2),
              Text(value, style: const TextStyle(color: AppTheme.textGrey, fontSize: 16, fontWeight: FontWeight.w800)),
            ],
          ),
        )
      ],
    );
  }
}

class _Blob extends StatelessWidget {
  final double size;
  final double opacity;
  final bool flip;

  const _Blob({required this.size, required this.opacity, this.flip = false});

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: flip ? 0.55 : -0.45,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(size),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              gradient: AppTheme.primaryGradient,
              borderRadius: BorderRadius.circular(size),
            ),
            child: Opacity(opacity: opacity, child: const SizedBox.shrink()),
          ),
        ),
      ),
    );
  }
}
