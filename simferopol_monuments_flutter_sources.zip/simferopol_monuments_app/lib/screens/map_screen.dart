import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../data/monuments.dart';
import '../models/monument.dart';
import '../theme/app_theme.dart';
import '../widgets/monument_sheet.dart';

class MapScreen extends StatelessWidget {
  final String lang;

  const MapScreen({super.key, required this.lang});

  @override
  Widget build(BuildContext context) {
    final isRu = lang == 'ru';
    return Scaffold(
      appBar: AppBar(
        title: Text(isRu ? 'Карта' : 'Map'),
      ),
      body: FlutterMap(
        options: MapOptions(
          initialCenter: const LatLng(44.9520, 34.1020),
          initialZoom: 13.0,
          interactionOptions: const InteractionOptions(
            flags: InteractiveFlag.all,
          ),
          onTap: (_, __) {},
        ),
        children: [
          // Offline tiles from assets/tiles/{z}/{x}/{y}.png
          TileLayer(
            urlTemplate: 'assets/tiles/{z}/{x}/{y}.png',
            tileProvider: AssetTileProvider(),
            userAgentPackageName: 'simferopol_monuments',
            errorTileCallback: (tile, error, stackTrace) {},
          ),
          MarkerLayer(markers: _buildMarkers(context)),
          // subtle legend/help
          Positioned(
            right: 12,
            top: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                color: AppTheme.glassWhite,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppTheme.lavender.withOpacity(0.45)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.place, color: AppTheme.purpleWarm, size: 18),
                  const SizedBox(width: 6),
                  Text(
                    isRu ? 'Нажмите на метку' : 'Tap a marker',
                    style: const TextStyle(color: AppTheme.softGrey, fontSize: 12),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<Marker> _buildMarkers(BuildContext context) {
    return monuments.map((m) => _markerFor(context, m)).toList();
  }

  Marker _markerFor(BuildContext context, Monument m) {
    return Marker(
      point: LatLng(m.lat, m.lng),
      width: 44,
      height: 44,
      child: GestureDetector(
        onTap: () {
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            backgroundColor: Colors.transparent,
            builder: (_) => MonumentSheet(monument: m, lang: lang),
          );
        },
        child: Container(
          decoration: BoxDecoration(
            color: AppTheme.purpleWarm.withOpacity(0.9),
            borderRadius: BorderRadius.circular(99),
            boxShadow: [
              BoxShadow(
                color: AppTheme.purpleWarm.withOpacity(0.25),
                blurRadius: 10,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: const Icon(Icons.place, color: Colors.white, size: 26),
        ),
      ),
    );
  }
}
