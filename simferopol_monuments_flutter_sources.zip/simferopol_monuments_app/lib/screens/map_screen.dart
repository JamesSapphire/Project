import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../data/monuments.dart';
import '../models/monument.dart';
import '../theme/app_theme.dart';
import '../widgets/monument_sheet.dart';

class MapScreen extends StatelessWidget {
  final String lang;

  const MapScreen({super.key, required this.lang});

  @override
  Widget build(BuildContext context) {
    final isRu = lang == 'ru';

    return Scaffold(
      appBar: AppBar(
        title: Text(isRu ? 'Карта' : 'Map'),
      ),
      body: FlutterMap(
        options: MapOptions(
          // Симферополь
          initialCenter: const LatLng(44.9520, 34.1020),
          initialZoom: 13.5,

          // "Городская" карта: не даём улетать далеко и не даём бессмысленно зумить
          minZoom: 12,
          maxZoom: 17,

          // Ограничиваем область города (примерно)
          cameraConstraint: CameraConstraint.contain(
            bounds: LatLngBounds(
              const LatLng(44.85, 33.95), // SW
              const LatLng(45.05, 34.28), // NE
            ),
          ),
          interactionOptions: const InteractionOptions(flags: InteractiveFlag.all),
        ),
        children: [
          // Online tiles (OpenStreetMap)
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'simferopol.monuments.app',
          ),

          MarkerLayer(markers: _buildMarkers(context)),

          // Small attribution (best practice)
          Positioned(
            left: 10,
            bottom: 10,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: AppTheme.glassWhite,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppTheme.lavender.withOpacity(0.45)),
              ),
              child: Text(
                isRu ? '© OpenStreetMap' : '© OpenStreetMap',
                style: TextStyle(color: AppTheme.textGrey.withOpacity(0.75), fontSize: 11.5),
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<Marker> _buildMarkers(BuildContext context) => monuments.map((m) => _markerFor(context, m)).toList();

  Marker _markerFor(BuildContext context, Monument m) {
    return Marker(
      point: LatLng(m.lat, m.lng),
      width: 36,
      height: 36,
      child: GestureDetector(
        onTap: () {
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            backgroundColor: Colors.transparent,
            builder: (_) => MonumentSheet(monument: m, lang: lang),
          );
        },
        child: Container(
          decoration: BoxDecoration(
            gradient: AppTheme.primaryGradient,
            borderRadius: BorderRadius.circular(99),
            boxShadow: [
              BoxShadow(
                color: AppTheme.purpleWarm.withOpacity(0.22),
                blurRadius: 14,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: const Icon(Icons.place, color: Colors.white, size: 22),
        ),
      ),
    );
  }
}
