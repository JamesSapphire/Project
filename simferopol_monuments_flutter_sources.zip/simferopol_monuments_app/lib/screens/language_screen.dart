import 'package:flutter/material.dart';
import '../services/prefs.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';

class LanguageScreen extends StatelessWidget {
  final String current;

  const LanguageScreen({super.key, required this.current});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(current == 'ru' ? 'Язык' : 'Language')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: GlassCard(
          child: Column(
            children: [
              _LangTile(
                title: 'Русский',
                selected: current == 'ru',
                onTap: () async {
                  await Prefs.setLang('ru');
                  if (context.mounted) Navigator.pop(context, 'ru');
                },
              ),
              const SizedBox(height: 10),
              _LangTile(
                title: 'English',
                selected: current == 'en',
                onTap: () async {
                  await Prefs.setLang('en');
                  if (context.mounted) Navigator.pop(context, 'en');
                },
              ),
              const Spacer(),
              Text(
                current == 'ru'
                    ? 'Выбор языка сохраняется и будет применён при следующем запуске.'
                    : 'Your choice is saved and will be used on the next launch.',
                style: TextStyle(color: AppTheme.softGrey.withOpacity(0.75)),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LangTile extends StatelessWidget {
  final String title;
  final bool selected;
  final VoidCallback onTap;

  const _LangTile({required this.title, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: selected ? AppTheme.purpleWarm : AppTheme.lavender.withOpacity(0.5), width: 1.4),
          color: selected ? AppTheme.lavender.withOpacity(0.18) : Colors.transparent,
        ),
        child: Row(
          children: [
            Expanded(child: Text(title, style: const TextStyle(fontSize: 16, color: AppTheme.softGrey))),
            if (selected)
              const Icon(Icons.check_circle, color: AppTheme.purpleWarm)
            else
              Icon(Icons.circle_outlined, color: AppTheme.softGrey.withOpacity(0.45)),
          ],
        ),
      ),
    );
  }
}
