class Monument {
  final String id;
  final double lat;
  final double lng;
  final String imageAsset;
  final Map<String, String> title;
  final Map<String, String> description;
  final String source;

  const Monument({
    required this.id,
    required this.lat,
    required this.lng,
    required this.imageAsset,
    required this.title,
    required this.description,
    required this.source,
  });

  String titleFor(String lang) => title[lang] ?? title.values.first;
  String descriptionFor(String lang) => description[lang] ?? description.values.first;
}
