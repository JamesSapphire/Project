import 'package:flutter/material.dart';
import '../models/monument.dart';
import '../theme/app_theme.dart';
import 'glass_card.dart';

class MonumentSheet extends StatelessWidget {
  final Monument monument;
  final String lang;

  const MonumentSheet({super.key, required this.monument, required this.lang});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
        child: GlassCard(
          padding: const EdgeInsets.all(14),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                height: 4,
                width: 42,
                decoration: BoxDecoration(
                  color: AppTheme.lavender.withOpacity(0.8),
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.asset(
                  monument.imageAsset,
                  height: 180,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  monument.titleFor(lang),
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: AppTheme.softGrey),
                ),
              ),
              const SizedBox(height: 8),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  monument.descriptionFor(lang),
                  style: TextStyle(fontSize: 14, height: 1.35, color: AppTheme.softGrey.withOpacity(0.95)),
                ),
              ),
              const SizedBox(height: 10),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Источник: ${monument.source}',
                  style: TextStyle(fontSize: 12, color: AppTheme.softGrey.withOpacity(0.7)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
