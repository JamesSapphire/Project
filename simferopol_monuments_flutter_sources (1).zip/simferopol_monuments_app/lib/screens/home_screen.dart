import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';
import 'language_screen.dart';
import 'map_screen.dart';

class HomeScreen extends StatefulWidget {
  final String lang;
  final ValueChanged<String> onLangChanged;

  const HomeScreen({super.key, required this.lang, required this.onLangChanged});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    final isRu = widget.lang == 'ru';
    return Scaffold(
      appBar: AppBar(
        title: Text(isRu ? 'Памятники Симферополя' : 'Simferopol Monuments'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isRu ? 'Интерактивная офлайн‑карта' : 'Interactive offline map',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: AppTheme.softGrey),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    isRu
                        ? 'Нажимайте на метки, чтобы увидеть фото и описание памятника.'
                        : 'Tap markers to see a photo and description.',
                    style: TextStyle(color: AppTheme.softGrey.withOpacity(0.9), height: 1.3),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: () async {
                final newLang = await Navigator.push<String>(
                  context,
                  MaterialPageRoute(builder: (_) => LanguageScreen(current: widget.lang)),
                );
                if (newLang != null) widget.onLangChanged(newLang);
              },
              icon: const Icon(Icons.language),
              label: Text(isRu ? 'Выбор языка' : 'Language'),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => MapScreen(lang: widget.lang)));
              },
              icon: const Icon(Icons.map_outlined),
              label: Text(isRu ? 'Перейти к карте' : 'Open map'),
            ),
            const Spacer(),
            OutlinedButton.icon(
              onPressed: () => SystemNavigator.pop(),
              icon: const Icon(Icons.exit_to_app),
              label: Text(isRu ? 'Выход' : 'Exit'),
            ),
            const SizedBox(height: 6),
            Text(
              isRu
                  ? 'Совет: добавьте офлайн-тайлы в assets/tiles/ для полноценной карты.'
                  : 'Tip: add offline tiles to assets/tiles/ for a full map.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppTheme.softGrey.withOpacity(0.65), fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
